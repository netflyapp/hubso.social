---
name: cc-skill-strategic-compact
description: "Development skill from everything-claude-code"
author: affaan-m
version: "1.0"
risk: unknown
source: community
---

# cc-skill-strategic-compact

Development skill skill.

## When to Use
This skill is applicable to execute the workflow or actions described in the overview.
