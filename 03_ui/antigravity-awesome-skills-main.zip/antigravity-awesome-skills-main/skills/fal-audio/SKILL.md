---
name: fal-audio
description: "Text-to-speech and speech-to-text using fal.ai audio models"
source: "https://github.com/fal-ai-community/skills/blob/main/skills/claude.ai/fal-audio/SKILL.md"
risk: safe
---

# Fal Audio

## Overview

Text-to-speech and speech-to-text using fal.ai audio models

## When to Use This Skill

Use this skill when you need to work with text-to-speech and speech-to-text using fal.ai audio models.

## Instructions

This skill provides guidance and patterns for text-to-speech and speech-to-text using fal.ai audio models.

For more information, see the [source repository](https://github.com/fal-ai-community/skills/blob/main/skills/claude.ai/fal-audio/SKILL.md).
