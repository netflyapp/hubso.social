---
name: fal-generate
description: "Generate images and videos using fal.ai AI models"
source: "https://github.com/fal-ai-community/skills/blob/main/skills/claude.ai/fal-generate/SKILL.md"
risk: safe
---

# Fal Generate

## Overview

Generate images and videos using fal.ai AI models

## When to Use This Skill

Use this skill when you need to work with generate images and videos using fal.ai ai models.

## Instructions

This skill provides guidance and patterns for generate images and videos using fal.ai ai models.

For more information, see the [source repository](https://github.com/fal-ai-community/skills/blob/main/skills/claude.ai/fal-generate/SKILL.md).
