---
name: nanobanana-ppt-skills
description: "AI-powered PPT generation with document analysis and styled images"
source: "https://github.com/op7418/NanoBanana-PPT-Skills"
risk: safe
---

# Nanobanana Ppt Skills

## Overview

AI-powered PPT generation with document analysis and styled images

## When to Use This Skill

Use this skill when you need to work with ai-powered ppt generation with document analysis and styled images.

## Instructions

This skill provides guidance and patterns for ai-powered ppt generation with document analysis and styled images.

For more information, see the [source repository](https://github.com/op7418/NanoBanana-PPT-Skills).
